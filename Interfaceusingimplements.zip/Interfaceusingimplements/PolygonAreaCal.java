package com.inapp.firstjava.util.interfce;

public interface PolygonAreaCal {

	public double calArea();
}
